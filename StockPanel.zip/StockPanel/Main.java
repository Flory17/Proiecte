package isp.lab9.exercise1;

import isp.lab9.exercise1.ui.LoginJFrame;

public class Main {
    public static void main(String[] args) {
        new LoginJFrame();
    }
}
