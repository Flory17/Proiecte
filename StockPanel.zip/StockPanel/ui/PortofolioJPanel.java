package isp.lab9.exercise1.ui;

import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;
import java.util.Map;

public class PortofolioJPanel extends JPanel {
    private StockMarketJFrame stockMarketJFrame;

    public PortofolioJPanel(StockMarketJFrame stockMarketJFrame) {
        this.stockMarketJFrame = stockMarketJFrame;
        init();
    }

    public void init() {
        setLayout(new GridLayout(0, 1)); // Folosim un layout GridLayout cu o singură coloană pentru a organiza componentele

        // Panou pentru titlu
        JPanel titlePanel = new JPanel();
        JLabel titleLabel = new JLabel("User Portfolio");
        titlePanel.add(titleLabel);

        // Panou pentru afișarea acțiunilor deținute
        JPanel portfolioStocksPanel = new JPanel();
        portfolioStocksPanel.setLayout(new GridLayout(0, 4)); // 4 coloane pentru simbol, cantitate, preț per unitate, preț total

        // Iterăm prin fiecare intrare din map-ul acțiunilor deținute și extragem informațiile necesare
        for (Map.Entry<String, Integer> entry : stockMarketJFrame.getPortfolio().getShares().entrySet()) {
            String symbol = entry.getKey();
            int quantity = entry.getValue();
            BigDecimal pricePerUnit = BigDecimal.ZERO; // Deocamdată, prețul pe unitate este setat la 0
            BigDecimal totalPrice = BigDecimal.ZERO; // Deocamdată, prețul total este setat la 0

            JLabel symbolLabel = new JLabel("Symbol: " + symbol);
            JLabel quantityLabel = new JLabel("Quantity: " + quantity);
            JLabel pricePerUnitLabel = new JLabel("Price per Unit: " + pricePerUnit);
            JLabel totalPriceLabel = new JLabel("Total Price: " + totalPrice);

            portfolioStocksPanel.add(symbolLabel);
            portfolioStocksPanel.add(quantityLabel);
            portfolioStocksPanel.add(pricePerUnitLabel);
            portfolioStocksPanel.add(totalPriceLabel);
        }

        // Adăugăm panourile în panoul principal
        add(titlePanel);
        add(portfolioStocksPanel);
    }
}
