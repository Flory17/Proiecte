package isp.lab10.raceapp;

public class Cronometru extends Thread{
    private boolean running = true;
    private long elapsedTime = 0;

    public void run() {
        while (running) {
            try {
                Thread.sleep(10);
                elapsedTime+=10;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public void stopTimer() {
        running = false;
    }

    public long getElapsedTime() {
        return elapsedTime;
    }
}
