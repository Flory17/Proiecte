package isp.lab10.raceapp;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Car Race");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CarPanel carPanel = new CarPanel();
        frame.getContentPane().add(carPanel);
        frame.pack();
        frame.setSize(500, 300);
        frame.setVisible(true);

        SemaphorePanel semaphorePanel = new SemaphorePanel();
        JFrame semaphoreFrame = new JFrame("Semaphore");
        semaphoreFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        semaphoreFrame.getContentPane().add(semaphorePanel);
        semaphoreFrame.pack();
        semaphoreFrame.setSize(200, 400);
        semaphoreFrame.setVisible(true);

        SemaphoreThread semaphoreThread = new SemaphoreThread(semaphorePanel);
        semaphoreThread.start();

        PlaySound playSound = new PlaySound();

        try {
            semaphoreThread.join();
            Car car1 = new Car("Red car", carPanel);
            Car car2 = new Car("Blue car", carPanel);
            Car car3 = new Car("Green car", carPanel);
            Car car4 = new Car("Yellow car", carPanel);
            playSound.playSound();
            car1.start();
            car2.start();
            car3.start();
            car4.start();

            car1.join();
            car2.join();
            car3.join();
            car4.join();
            playSound.stopSound();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
