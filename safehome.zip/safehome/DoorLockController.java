package isp.lab7.safehome;

import java.util.HashMap;
import java.util.Map;

public class DoorLockController {
    private Map<Tenant, AccessKey> validAccess = new HashMap<>();

    public void addTenant(String pin, String name) throws TenantAlreadyExistsException, InvalidPinException {
        AccessKey accessKey = new AccessKey(pin);
        Tenant tenant = new Tenant(name);

        if (!validAccess.containsKey(tenant)) {
            if (pinIsValid(pin)) {
                validAccess.put(tenant, accessKey);
                System.out.println("Added new tenant: " + name);
            } else {
                throw new InvalidPinException("Invalid PIN format");
            }
        } else {
            throw new TenantAlreadyExistsException(name);
        }
    }

    private boolean pinIsValid(String pin) {
        // Verificăm dacă PIN-ul are formatul corect (de exemplu, este format din patru cifre)
        return pin.matches("\\d{4}");
    }

    public void removeTenant(String name) throws TenantNotFoundException {
        // Implementarea eliminării chiriașului
        throw new UnsupportedOperationException("Not implemented yet!");
    }

    public DoorStatus enterPin(String pin) throws TooManyAttemptsException {
        // Implementarea verificării PIN-ului și deschiderii ușii
        throw new UnsupportedOperationException("Not implemented yet!");
    }
}
