package isp.lab7.safehome;



public enum DoorStatus {
    OPEN,    // Door is unlocked and open
    CLOSED,  // Door is locked
    LOCKED   // Door is locked and secured
}
