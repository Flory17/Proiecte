package isp.lab7.safehome;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        DoorLockController controller = new DoorLockController();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("SafeHome Menu:");
            System.out.println("1. Add Tenant");
            System.out.println("2. Remove Tenant");
            System.out.println("3. Enter PIN");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consumă newline

            switch (choice) {
                case 1:
                    System.out.println("Enter tenant name:");
                    String name = scanner.nextLine();
                    System.out.println("Enter PIN:");
                    String pin = scanner.nextLine();
                    try {
                        controller.addTenant(pin, name);
                        System.out.println("Tenant added successfully.");
                    } catch (TenantAlreadyExistsException | InvalidPinException e) {
                        System.err.println("Failed to add tenant: " + e.getMessage());
                    }
                    break;
                case 2:
                    System.out.println("Enter tenant name to remove:");
                    String removeName = scanner.nextLine();
                    try {
                        controller.removeTenant(removeName);
                        System.out.println("Tenant removed successfully.");
                    } catch (TenantNotFoundException e) {
                        System.err.println("Failed to remove tenant: " + e.getMessage());
                    }
                    break;
                case 3:
                    System.out.println("Enter PIN:");
                    String enteredPin = scanner.nextLine();
                    try {
                        DoorStatus status = controller.enterPin(enteredPin);
                        System.out.println("Door status: " + status);
                    } catch (TooManyAttemptsException e) {
                        System.err.println("Too many failed attempts. Door locked temporarily.");
                    }
                    break;
                case 4:
                    System.out.println("Exiting SafeHome. Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please choose a valid option.");
            }
        }
    }
}
