package isp.lab7.safehome;

public class SafeHome {

    public static void main(String[] args) {

    }
}
