package isp.lab7.safehome;

public class TenantAlreadyExistsException extends Exception {
    public TenantAlreadyExistsException(String name) {
        super("Tenant " + name + " already exists!");
    }
}
