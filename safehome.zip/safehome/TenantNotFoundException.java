package isp.lab7.safehome;

public class TenantNotFoundException extends Exception {
    public TenantNotFoundException(String name) {
        super("Tenant not found: " + name);
    }
}
