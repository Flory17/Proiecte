package isp.lab7.safehome;

public class TooManyAttemptsException extends Exception {
    public TooManyAttemptsException() {
        super("Too many failed attempts. Door locked temporarily.");
    }
}
